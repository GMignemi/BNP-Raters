#' BNP Analysis of Multiple Raters Coarsened Ratings
#'
#'This function returns mcmc samples from the BNP model for coarsened ratings.
#'
#'
#' @param data A list of: OBSERVED SCORE - SUBJECT ID - RATER ID
#' @param nMaxClusters_s Maximum number of subjects clusters
#' @param nMaxClusters Maximum number of raters clusters
#' @param Grid_s Grid of equidistant points for the monitoring of the TRUE SCORE density
#' @param Grid Grid of equidistant points for the monitoring of the RATER SYSTEMATIC BIAS density
#' @param Grid_rel Grid of equidistant points for the monitoring of the RATER RELIABILITY density
#' @param cutoff Vector of cutoffs
#' @param nIter Number of iterations
#' @param burnIn Number of burn-in samples
#' @param Thin Thin factor
#' @param Priors List of Hyperparameters
#' @param seed Set seed
#'
#' @return A list containing MCMCM samples form the BNP Model
#' @export
#'
#'
#'
#'
#'
R_coarse_BNP_mcmc = function(
    data,  #list
    nMaxClusters_s,
    nMaxClusters,
    Grid_s,
    Grid,
    Grid_rel,
    cutoff,
    #MCMC
    nIter,
    burnIn,
    Thin,
    Priors, #list
    seed
){

  # Packages
  if (!require(mvtnorm)) install.packages("mvtnorm")
  if (!require(invgamma)) install.packages("invgamma")
  if (!require(Matrix)) install.packages("Matrix")
  if (!require(Matrix)) install.packages("truncnorm")

  library("mvtnorm")
  library("invgamma")
  library("Matrix")
  library("truncnorm")


  p               = 1     #number of covariates for fixed effects
  q               = 1     #number of covariates for random effects

  nrep            = 1


  # Data Preparation

  J               = max(data[,2])
  I               = max(data[,3])
  id_raters       = table(data[,3])

  tot             = length(data[,1])
  K               = length(table(data[,1]))


  for(i in 1:I){
    data[which(data[,3]==names(id_raters)[i]),3] = i
  }


  Q_mat = matrix(0,J,I)                                                              # maps the subjetcs into the raters

  for(j in 1:J){
    dd          = as.numeric(data[which(data[,2]==j),3])
    Q_mat[j,dd] = 1
  }

  #yy=apply(Q_mat,2,sum)
  #which(yy==1)

  # apply(Q_mat,1,sum)

  MM = as.numeric(data[,2])
  RR = as.numeric(data[,3])


  Zj = matrix(0,tot,J)

  for(nn in 1:tot){
    Zj[nn,MM[nn]] = 1
  }
  #apply(Zj,1,sum)
  #apply(Zj,2,sum)


  Z  = matrix(0,tot,I)

  for(n in 1:tot){
    Z[n,RR[n]] = 1
  }
  # ------------------------------------------------------------------------------
  m_0             = Priors$m_0
  m_0_r           = Priors$m_0_r
  sigma_s_0       = Priors$sigma_s_0
  a_0             = Priors$a_0
  b_0             = Priors$b_0
  a_b             = Priors$a_b
  b_b             = Priors$b_b
  a_alpha         = Priors$a_alpha
  b_alpha         = Priors$b_alpha
  a_alpha_1       = Priors$a_alpha_1
  b_alpha_1       = Priors$b_alpha_1
  a_0h            = Priors$a_0h
  b_0h            = Priors$b_0h
  a_mu_0          = Priors$a_mu_0
  b_mu_0          = Priors$b_mu_0
  # ------------------------------------------------------------------------------
  # ------------------------------------------------------------------------------
  # ------------------------------------------------------------------------------


  mu_G_mean_rep      = array( 0, dim = c( 1, nrep) )
  mu_G_025_rep       = array( 0, dim = c( 1, nrep) )
  mu_G_975_rep       = array( 0, dim = c( 1, nrep) )

  mu_0_mean_rep      = array( 0, dim = c( 1, nrep) )
  mu_0_025_rep       = array( 0, dim = c( 1, nrep) )
  mu_0_975_rep       = array( 0, dim = c( 1, nrep) )


  Theta_mean_rep        = array( 0, dim = c( J, nrep) )
  Theta_025_rep         = array( 0, dim = c( J, nrep) )
  Theta_975_rep         = array( 0, dim = c( J, nrep) )

  var_S_mean_rep        = array( 0, dim = c( 1, nrep) )
  var_S_025_rep         = array( 0, dim = c( 1, nrep) )
  var_S_975_rep         = array( 0, dim = c( 1, nrep) )

  b_mean_rep            = array( 0, dim = c( I, nrep) )
  b_025_rep             = array( 0, dim = c( I, nrep) )
  b_975_rep             = array( 0, dim = c( I, nrep) )

  var_B_mean_rep        = array( 0, dim = c( 1, nrep) )
  var_B_025_rep         = array( 0, dim = c( 1, nrep) )
  var_B_975_rep         = array( 0, dim = c( 1, nrep) )


  xi_mean_rep          = array( 0, dim = c( I, nrep) )
  xi_025_rep           = array( 0, dim = c( I, nrep) )
  xi_975_rep           = array( 0, dim = c( I, nrep) )


  var_Rel_mean_rep     = array( 0, dim = c( 1, nrep) )
  var_Rel_025_rep      = array( 0, dim = c( 1, nrep) )
  var_Rel_975_rep      = array( 0, dim = c( 1, nrep) )
  ICC_mean_rep         = array( 0, dim = c( 1, nrep) )
  ICC_025_rep          = array( 0, dim = c( 1, nrep) )
  ICC_975_rep          = array( 0, dim = c( 1, nrep) )

  Density_1_mean     = array( 0, dim = c( nrep,length(Grid_s)) )
  Density_1_025      = array( 0, dim = c( nrep,length(Grid_s)) )
  Density_1_975      = array( 0, dim = c( nrep,length(Grid_s)) )

  Density_2_mean     = array( 0, dim = c( nrep,length(Grid)) )
  Density_2_025      = array( 0, dim = c( nrep,length(Grid)) )
  Density_2_975      = array( 0, dim = c( nrep,length(Grid)) )

  Density_3_mean     = array( 0, dim = c( nrep,length(Grid_rel)) )
  Density_3_025      = array( 0, dim = c( nrep,length(Grid_rel)) )
  Density_3_975      = array( 0, dim = c( nrep,length(Grid_rel)) )


  ################################################################################
  ################################################################################

  for(ff in 1:nrep){

    ##############################################################################################
    # ------------------------------ DATA SET UP--------------------------------------------------

    y               = as.numeric(data[,1])
    toll            = 10^(-8)
    M               = 10
    par(mfrow=c(1,1))

    #...... preallocation

    mu_0                  = array( 0, dim = c( nIter+1, q) )
    sigma_0               = array( 0, dim = c( nIter+1, q) )
    eta_0                 = array( 0, dim = c( nIter+1, q) )
    sigma_eta_0           = array( 0, dim = c( nIter+1, q) )
    phi                   = array( 0, dim = c( nMaxClusters, q, nIter+1) )
    sigma_b               = array( 0, dim = c( nIter+1, q, nMaxClusters) )
    phi_s                 = array( 0, dim = c( nMaxClusters_s, q, nIter+1) )
    sigma_s               = array( 0, dim = c( nIter+1, q, nMaxClusters_s) )
    mean_mix_s            = array( 0, dim =  c( 1, nIter+1) )
    var_mix_s             = array( 0, dim =  c( 1, nIter+1) )
    mean_mix_r            = array( 0, dim =  c( 1, nIter+1) )
    var_mix_r             = array( 0, dim =  c( 1, nIter+1) )
    var_rel               = array( 0, dim =  c( 1, nIter+1) )
    ICC_a                 = array( 0, dim =  c( 1, nIter+1) )
    pi_c_r                = array( 0, dim = c( nIter+1, nMaxClusters) )
    pi_c_s                = array( 0, dim = c( nIter+1, nMaxClusters_s) )
    c_s                   = array( 0, dim = c( J, nIter+1) )
    c_r                   = array( 0, dim = c( I, nIter+1) )
    N_groups_s            = array( 0, dim =  c( 1, nIter+1) )
    N_groups              = array( 0, dim =  c( 1, nIter+1) )
    ni_c_s                = array( 0, dim = c( nMaxClusters_s, nIter+1) )
    ni_c                  = array( 0, dim = c( nMaxClusters, nIter+1) )
    alpha_0_1             = array( 0, dim = c( 1, nIter+1) )
    alpha_0               = array( 0, dim = c( 1, nIter+1) )
    nu_1                  = array( 0, dim = c( nMaxClusters_s, nIter+1) )
    nu                    = array( 0, dim = c( nMaxClusters, nIter+1) )
    theta                 = array( 0, dim = c( J, q, nIter+1) )
    theta_C               = array( 0, dim = c( J, q, nIter+1) )
    b                     = array( 0, dim = c( I, q, nIter+1) )
    b_C                   = array( 0, dim = c( I, q, nIter+1) )
    mu                    = array( 0, dim = c( J, q, nIter+1) )
    sigma                 = array( 0, dim = c( J, q, nIter+1) )
    eta                   = array( 0, dim = c( I, q, nIter+1) )
    omega                 = array( 0, dim = c( I, q, nIter+1) )
    sigma_2               = array( 0, dim =  c( I, nIter+1) )
    precis_2              = array( 0, dim =  c( I, nIter+1) )
    par_monitoring_s      = array( 0, dim =  c( length(Grid_s), nIter+1) )
    par_monitoring        = array( 0, dim =  c( length(Grid), nIter+1) )
    par_monitoring_rel    = array( 0, dim =  c( length(Grid_rel), nIter+1) )
    MSE_precis_2           = array( 0, dim =  nIter+1)
    mu_h                  = array( 0, dim =  c( nMaxClusters, nIter+1))
    alpha_h               = array( 0, dim =  c( nMaxClusters, nIter+1))
    mu_h_i                = array( 0, dim =  c(I, nIter+1))
    alpha_h_i             = array( 0, dim =  c(I, nIter+1))
    sigma_mean            = array( 0, dim =  c( 1, nIter+1))
    a_sigma               = array( 0, dim =  c( 1, nIter+1))
    sigma_mean_b          = array( 0, dim =  c( 1, nIter+1))
    a_sigma_b             = array( 0, dim =  c( 1, nIter+1))
    a_0h_mu               = array( 0, dim =  c( 1, nIter+1))
    b_0h_mu               = array( 0, dim =  c( 1, nIter+1))
    a_0h_alpha            = array( 0, dim =  c( 1, nIter+1))
    b_0h_alpha            = array( 0, dim =  c( 1, nIter+1))


    # ------ Initial quantities

    mu_0[1,]              = 0
    sigma_0[1,]           = 2
    eta_0[1,]             = 0
    sigma_eta_0[1,]       = 2


    phi_s[,,1]            = 0
    sigma_s[1,,]          = 2
    phi[,,1]              = 0
    sigma_b[1,,]          = 2

    mu_h[,1]              = 1
    alpha_h[,1]           = 1



    # --- subjects allocation
    pi_c_s[1,]            = rep(1/nMaxClusters,nMaxClusters)
    c_s[,1]                 = sample(1:nMaxClusters, J, prob=pi_c_s[1,], replace = TRUE)
    phi_s[,,1]            = rmvnorm(nMaxClusters, mu_0[1,], sqrt(sigma_0[1,]*diag(q)) )
    for(hh in 1:nMaxClusters){
      for(j in 1:J){
        if(c_s[j,1] == hh){
          theta[j,,1]         = rmvnorm(q, phi_s[hh,,1], sigma_s[1,,hh]*diag(q) )
        }
      }
    }
    mean_mix_s[1]           = pi_c_s[1,] %*% phi_s[,1,1]
    var_mix_s[1]            = pi_c_s[1,] %*% (sigma_s[1,1,] + phi_s[,1,1]^2) - mean_mix_s[1]^2

    theta_C[,,1]            =  theta[,,1] - mean_mix_s[1]

    for(j in 1:J){
      for(hh in 1:nMaxClusters){
        if(c_s[j,1] == hh){
          ni_c_s[hh,1]       =  ni_c_s[hh,1]+1
        }
      }
    }

    # --- raters allocation
    pi_c_r[1,]              = rep(1/nMaxClusters,nMaxClusters)
    c_r[,1]                 = sample(1:nMaxClusters, I, prob=pi_c_r[1,], replace = TRUE)
    phi[,,1]                = rmvnorm(nMaxClusters, eta_0[1,], sqrt(sigma_eta_0[1,]*diag(q)) )
    for(hh in 1:nMaxClusters){
      for(ii in 1:I){
        if(c_r[ii,1] == hh){
          eta[ii,,1]         = rmvnorm(q, phi[hh,,1], sigma_b[1,,hh]*diag(q) )
        }
      }
    }
    mean_mix_r[1]          = pi_c_r[1,] %*% phi[,1,1]
    var_mix_r[1]           = pi_c_r[1,] %*% (sigma_b[1,1,] + phi[,1,1]^2) - mean_mix_r[1]^2


    for(ii in 1:I){
      for(hh in 1:nMaxClusters){
        if(c_r[ii,1] == hh){
          ni_c[hh,1]       =  ni_c[hh,1]+1
        }
      }
    }

    sigma_2[,1]      = 5
    precis_2[,1]     = 1/5


    mu_h_i[,1]       = 5
    alpha_h_i[,1]    = 5

    a_sigma[1]       = 4
    sigma_mean[1]    = 4

    a_sigma_b[1]     = 10
    sigma_mean_b[1]  = 1

    a_0h_mu[1]       = 1
    b_0h_mu[1]       = 1

    a_0h_alpha[1]    = 1
    b_0h_alpha[1]    = 1



    ##############################################################################################
    # ----------------------------------- SAMPLING  ----------------------------------------------
    start.time <- Sys.time()

    for(kk in 1:nIter){
      #------Latent Variable Formulation through Ordered Heteroscedastic Probit

       U = rep(NA,tot)

      for(nn in 1:tot){
        if (y[nn]==1){
          U[nn]              = rtruncnorm(1, -Inf, cutoff[1], mean = theta_C[MM[nn],1,kk] + b_C[RR[nn],1,kk], sd = sqrt(sigma_2[RR[nn],kk]))
        }

        for(cat in 2:(K-1)){
          if (y[nn]==cat){
            U[nn]            = rtruncnorm(1, cutoff[cat-1], cutoff[cat], mean = theta_C[MM[nn],1,kk] + b_C[RR[nn],1,kk], sd = sqrt(sigma_2[RR[nn],kk]))
          }
        }

        if (y[nn]==K){
          U[nn]              = rtruncnorm(1, cutoff[K-1], Inf, mean = theta_C[MM[nn],1,kk] + b_C[RR[nn],1,kk], sd = sqrt(sigma_2[RR[nn],kk]))
        }

      }



      #--------------------------- Update parameters referring to the Subjects --------------------------------



      for(j in 1:J){

        Sigma_2i              = sigma_2[which(Q_mat[j,]==1),kk]*diag(length(which(Zj[,j]==1)))

        sigma_2_j             = t(Zj[which(Zj[,j]==1),j]) %*%  solve(Sigma_2i) %*% Zj[which(Zj[,j]==1),j]

        Sigma_s               = sigma_s[kk,1,c_s[j,kk]]*diag(q)

        Sigma_theta_j         = solve( solve(Sigma_s) + sigma_2_j)

        mu_theta_j            = solve( solve(Sigma_s) + sigma_2_j) *
          ( solve(Sigma_s) * mu[j,1,kk] +
              t(U[which(Zj[,j]==1)] - b_C[which(Q_mat[j,]==1),,kk]) %*% solve(Sigma_2i) %*% Zj[which(Zj[,j]==1),j] )  # ???

        theta[j,,kk+1]       = rmvnorm( 1, mu_theta_j, sqrt(Sigma_theta_j))
        # theta[j,,kk+1]        = synt_data$theta[j] + alpha_s
      }

      # ---- SEMI -Centering

      theta_C[,1,kk+1]           = theta[,1,kk+1] # - mean_mix_s[kk]
      # theta[,,kk+1]           = theta[,,kk+1] - mean_mix_s[kk]


      # ---- Clusters
      for(hh in 1:nMaxClusters){
        if(ni_c_s[hh,kk]<1){
          phi_s[hh,,kk+1]         = rmvnorm(1, mu_0[kk,], sqrt(sigma_0[kk,]*diag(q)))
          sigma_s[kk+1,,hh]       = rinvgamma(1, a_sigma[kk] ,a_sigma[kk]/sigma_mean[kk]  )

        } else{
          for(qq in q){
            index                 = which(c_s[,kk] == hh)
            mean_theta            = mean(theta[index , qq, kk+1])

            mu_0_star             = solve( ni_c_s[hh,kk]/sigma_s[kk,qq,hh]+1/sigma_0[kk,qq] ) * ( ni_c_s[hh,kk]/sigma_s[kk,qq,hh] * mean_theta + mu_0[kk,qq]/sigma_0[kk,qq] )
            sigma_0_star          = solve( ni_c_s[hh,kk]/sigma_s[kk,qq,hh]+1/sigma_0[kk,qq] )

            phi_s[hh,qq,kk+1]    = rnorm(1, mu_0_star, sqrt(sigma_0_star))

            sigma_s[kk+1,qq,hh]  = rinvgamma(1, a_sigma[kk] + 0.5 * ni_c_s[hh,kk], a_sigma[kk]/sigma_mean[kk]  + 0.5 *
                                               sum((theta[index , qq, kk+1] - mean_theta)^2))
          }
        }
      }


      #----- jj Allocation  # You could try with the log

      for(j in 1:J){
        pi_s                    = array( 0, dim = c( J, nMaxClusters) )
        for(hh in 1:nMaxClusters){
          pi_s[j,hh]           = log(pi_c_s[kk,hh]) + dnorm( theta[j,1,kk+1], phi_s[hh,1,kk+1], sqrt(sigma_s[kk+1,1,hh]), log = TRUE )
        }

        pro                   = exp(pi_s[j,] - max(pi_s[j,]))/sum(exp(pi_s[j,] - max(pi_s[j,])))                       #Log-weight trick to get rid of numerical problems

        c_s[j,kk+1]           = sample(1:nMaxClusters, 1 , prob=pro)
        mu[j,1,kk+1]          = phi_s[c_s[j,kk+1],1,kk+1]
        sigma[j,1,kk+1]       = sigma_s[kk+1,1,c_s[j,kk+1]]
      }

      N_groups_s[kk+1]        = length(table(mu[,,kk+1]))

      #----- Stick-Breaking
      for(hh in 1:nMaxClusters){
        ni_c_s[hh,kk+1] = length(which(c_s[,kk+1] == hh))
      }

      if (alpha_0_1[kk] == 0){
        alpha_0_1[kk]           = 0.1                                                 # to avoid an improper beta per the empty clusters
      }
      for( jj in 1:nMaxClusters ){
        if( jj < nMaxClusters ){
          nl_1                  = ni_c_s[(jj+1):nMaxClusters,kk+1]
          # nu[jj,kk+1]         = rbeta(1, 1 - d + ni_c[jj], alpha_0[kk] + jj*d + sum(nl))
          nu_1[jj,kk+1]         = rbeta(1, 1 + ni_c_s[jj,kk+1] , alpha_0_1[kk] + sum(nl_1))

        } else{
          nu_1[jj,kk+1]         = 1
        }
        nu_l_1                  = nu_1[1:(jj-1),kk+1]
        pi_c_s[kk+1,jj]         = nu_1[jj,kk+1] * prod(1 - nu_l_1)
      }

      alpha_0_1[kk+1]           = rgamma(1, a_alpha_1 + nMaxClusters -1, b_alpha_1 - sum(log(1-nu_1[1:(nMaxClusters-1),kk+1])))

      #----- Par mixture
      # univariate case
      mean_mix_s[kk+1]           = t(pi_c_s[kk+1,]) %*% phi_s[,1,kk+1]
      var_mix_s[kk+1]            = t(pi_c_s[kk+1,]) %*% (sigma_s[kk+1,1,] + phi_s[,1,kk+1]^2) - mean_mix_s[kk+1]^2 #

      #----- Base measure parameters for mu and omega

      for(qq in 1:q){
        # mu
        mu_0[kk+1,qq]         = rnorm(1, solve(J/sigma_0[kk,qq] + 1/sigma_s_0[qq]) *
                                        (J/sigma_0[kk,qq] * mean(mu[,qq,kk+1])  + m_0[qq]/sigma_s_0[qq]),
                                      sqrt(solve(J/sigma_0[kk,qq] + 1/sigma_s_0[qq])))


        sigma_0[kk+1,qq]      = rinvgamma(1, a_0 + 0.5 * J, b_0 + 0.5 * sum((mu[,qq,kk+1] - mu_0[kk+1,qq])^2) )

        # omega

        R                      = sum(log(1/ sigma[,1,kk+1]   ))
        S                      = sum(1/sigma[,1,kk+1] )

        sigma_mean[kk+1]       = rinvgamma(1,a_mu_0+J*(a_sigma[kk]),b_mu_0 + (a_sigma[kk])*S)

        TT                     = S/sigma_mean[kk+1] - R + J*log(sigma_mean[kk+1]) - J

        A                      = a_0h + J/2
        B                      = b_0h + TT

        for(mm in 1:M){

          a    = A/B
          A    = a_0h - J*a + J * a^2*trigamma(a)
          B    = b_0h + (A-a_0h)/a - J*log(a) + J*digamma(a)+TT

          if(abs(a/(A/B)-1)<toll){break}
        }

        a_sigma[kk+1]  = rgamma(1,A,B)



      }



      #--------------------------- Update parameters referring to the Raters --------------------------------

      for(ii in 1:I){
        Sigma_bc              = sigma_b[kk,,c_r[ii,kk]]*diag(q)
        Sigma_b_i             = solve( solve(Sigma_bc) + t(Z[which(Z[,ii]==1),ii]) %*% Z[which(Z[,ii]==1),ii] / sigma_2[ii,kk])

        mu_b_i                = solve( solve(Sigma_bc) + t(Z[which(Z[,ii]==1),ii]) %*% Z[which(Z[,ii]==1),ii] / sigma_2[ii,kk]) *
          ( solve(Sigma_bc) * eta[ii,,kk] + t(Z[which(Z[,ii]==1),ii]) %*% ( U[which(Z[,ii]==1)] - theta[which(Q_mat[,ii]==1),,kk+1])/ sigma_2[ii,kk] )

        b[ii,1,kk+1]           = rmvnorm( 1, mu_b_i, sqrt(Sigma_b_i))


        # ---- SEMI -Centering
        b_C[ii,,kk+1]         = b[ii,,kk+1] # - mean_mix_r[kk]
        # b[ii,,kk+1]           = b[ii,,kk+1] - mean_mix_r[kk]


        precis_2[ii,kk+1]      = rgamma(1, (alpha_h_i[ii,kk]+1) + 0.5 * length(which(Q_mat[,ii]==1)) , (alpha_h_i[ii,kk]+1) / mu_h_i[ii,kk] + 0.5 *
                                          sum(( U[which(Z[,ii]==1)] - theta[which(Q_mat[,ii]==1),1,kk+1] - b[ii,1,kk+1])^2) ) # to check ???


        sigma_2[ii,kk+1]      = 1/precis_2[ii,kk+1]
      }



      for(hh in 1:nMaxClusters){
        if(ni_c[hh,kk]<1){
          phi[hh,,kk+1]            = rmvnorm(1, eta_0[kk,], sqrt(sigma_eta_0[kk,]*diag(q)))
          sigma_b[kk+1,,hh]        = rinvgamma(1, a_sigma_b[kk] , a_sigma_b[kk]/sigma_mean_b[kk] )

          mu_h[hh,kk+1]            = rinvgamma(1, a_0h_mu[kk] , a_0h_mu[kk]/b_0h_mu[kk] )
          alpha_h[hh,kk+1]         = rgamma(1,    a_0h_alpha[kk] , a_0h_alpha[kk]/b_0h_alpha[kk] )


        } else{
          for(qq in q){
            index                  = which(c_r[,kk] == hh)
            mean_b                 = mean(b[index , qq, kk+1])
            eta_0_star             = solve( ni_c[hh,kk]/sigma_b[kk,qq,hh] +1/sigma_eta_0[kk,qq] ) * ( ni_c[hh,kk]/sigma_b[kk,qq,hh]* mean_b + eta_0[kk,qq]/sigma_eta_0[kk,qq] )
            sigma_eta_0_star       = solve( ni_c[hh,kk]/sigma_b[kk,qq,hh]+ 1/sigma_eta_0[kk,qq] )

            phi[hh,qq,kk+1]        = rnorm(1, eta_0_star, sqrt(sigma_eta_0_star))
            sigma_b[kk+1,qq,hh]    = rinvgamma(1, a_sigma_b[kk] + 0.5 * ni_c[hh,kk], a_sigma_b[kk]/sigma_mean_b[kk] + 0.5 * (sum((b[index , qq, kk+1] - mean_b)^2)) )


            # ---- Reliability

            R                = sum(log(precis_2[index,kk+1]))
            S                = sum(precis_2[index,kk+1])
            #  # W_s              = sum(1/sigma_2[index,kk+1])
            mu_h[hh,kk+1]    = rinvgamma(1,a_0h_mu[kk]+ni_c[hh,kk]*(1+alpha_h[hh,kk]),a_0h_mu[kk]/b_0h_mu[kk] + (1+alpha_h[hh,kk])*S)

            TT               = S/mu_h[hh,kk+1] - R + ni_c[hh,kk]*log(mu_h[hh,kk+1]) - ni_c[hh,kk]

            A    =  a_0h_alpha[kk] + ni_c[hh,kk]/2
            B    =  a_0h_alpha[kk]/ b_0h_alpha[kk] + TT

            for(mm in 1:M){

              a    = A/B
              A    = a_0h_alpha[kk]  + ni_c[hh,kk] * a^2*trigamma(1+a) -  ni_c[hh,kk]*a^2*1/(1+a)
              B    = a_0h_alpha[kk]/ b_0h_alpha[kk] + (A-a_0h_alpha[kk])/a - ni_c[hh,kk]*log(1+a) + ni_c[hh,kk]*digamma(1+a)+TT

              if(abs(a/(A/B)-1)<toll){break}
            }

            alpha_h[hh,kk+1]  = rgamma(1,A,B)

          }
        }
      }
      # ------------
      # MSE_precis_2[kk+1] = mean((precis_2[,kk+1] - synt_data$xi)^2)

      #----- ii Allocation  # You could try with the log
      for(ii in 1:I){
        pi                    = array( 0, dim = c( I, nMaxClusters) )
        for(hh in 1:nMaxClusters){
          pi[ii,hh]           = log(pi_c_r[kk,hh]) +
            dnorm( b[ii,1,kk+1], phi[hh,1,kk+1], sqrt(sigma_b[kk+1,1,hh]), log = TRUE ) +
            dgamma(precis_2[ii,kk+1],alpha_h[hh,kk+1]+1,(1+alpha_h[hh,kk+1])/mu_h[hh,kk+1], log= TRUE)
        }


        pro                   = exp(pi[ii,] - max(pi[ii,]))/sum(exp(pi[ii,] - max(pi[ii,])))                      #Log-weight trick to get rid of numerical problems

        c_r[ii,kk+1]          = sample(1:nMaxClusters, 1 , prob=pro)

        eta[ii,,kk+1]         = phi[c_r[ii,kk+1],1,kk+1]
        omega[ii,,kk+1]       = sigma_b[kk+1,1,c_r[ii,kk+1]]

        mu_h_i[ii,kk+1]       = mu_h[c_r[ii,kk+1],kk+1]
        alpha_h_i[ii,kk+1]    = alpha_h[c_r[ii,kk+1],kk+1]

      }

      DDD                     = unique(cbind(eta[,1,kk+1],omega[,1,kk+1],mu_h_i[,kk+1],alpha_h_i[,kk+1]))

      N_groups[kk+1]          = dim(DDD)[1]

      #----- Stick-Breaking
      for(hh in 1:nMaxClusters){
        ni_c[hh,kk+1] = length(which(c_r[,kk+1] == hh))
      }

      if (alpha_0[kk] == 0){
        alpha_0[kk]           = 0.1                                       # to avoid an improper beta per the empty clusters
      }

      for( jj in 1:nMaxClusters ){
        if( jj < nMaxClusters ){
          nl                    = ni_c[(jj+1):nMaxClusters,kk+1]
          # nu[jj,kk+1]         = rbeta(1, 1 - d + ni_c[jj], alpha_0[kk] + jj*d + sum(nl))
          nu[jj,kk+1]           = rbeta(1, 1 + ni_c[jj,kk+1] , alpha_0[kk] + sum(nl))

        } else{
          nu[jj,kk+1]         = 1
        }
        nu_l                  = nu[1:(jj-1),kk+1]
        pi_c_r[kk+1,jj]       = nu[jj,kk+1] * prod(1 - nu_l)
      }


      #----- Par mixture
      # univariate case
      mean_mix_r[kk+1]           = pi_c_r[kk+1,] %*% phi[,1,kk+1]
      var_mix_r[kk+1]            = pi_c_r[kk+1,] %*% (sigma_b[kk+1,1,] + phi[,1,kk+1]^2) - mean_mix_r[kk+1]^2 #

      var_rel[kk+1]              = pi_c_r[kk+1,] %*% ((alpha_h[,kk+1]+1)/(mu_h[,kk+1] * alpha_h[,kk+1] ))

      ICC_a[kk+1]                = var_mix_s[kk+1] / (var_mix_s[kk+1] + var_mix_r[kk+1] + var_rel[kk+1])

      alpha_0[kk+1]              = rgamma(1, a_alpha + nMaxClusters -1, b_alpha - sum(log(1-nu[1:(nMaxClusters-1),kk+1])))


      #----- Base measure parameters for eta

      for(qq in 1:q){

        # eta

        eta_0[kk+1,qq]         = rnorm(1, solve(I/sigma_eta_0[kk,qq] + 1/sigma_s_0[qq]) *
                                         (I/sigma_eta_0[kk,qq] * mean(eta[,qq,kk+1])  + m_0_r[qq]/sigma_s_0[qq]),
                                       sqrt(solve(I/sigma_eta_0[kk,qq] + 1/sigma_s_0[qq])))


        sigma_eta_0[kk+1,qq]   = rinvgamma(1, a_0 + 0.5 * I, b_0 + 0.5 * sum((eta[,qq,kk+1] - eta_0[kk+1,qq])^2) )


        #

        R                      = sum(log(1/omega[,1,kk+1]))
        S                      = sum(1/omega[,1,kk+1])

        sigma_mean_b[kk+1]     = rinvgamma(1,a_mu_0+I*(a_sigma_b[kk]),b_mu_0 + (a_sigma_b[kk])*S)

        TT                     = S/sigma_mean_b[kk+1] - R + I*log(sigma_mean_b[kk+1]) - I

        A                      = a_0h + I/2
        B                      = b_0h + TT

        for(mm in 1:M){

          a    = A/B
          A    = a_0h - I*a + I * a^2*trigamma(a)
          B    = b_0h + (A-a_0h)/a - I*log(a) +I*digamma(a)+TT

          if(abs(a/(A/B)-1)<toll){break}
        }

        a_sigma_b[kk+1]  = rgamma(1,A,B)


        # mu_h

        R                      = sum(log(1/mu_h_i[,kk+1]))
        S                      = sum(1/mu_h_i[,kk+1])

        b_0h_mu[kk+1]          = rinvgamma(1,a_mu_0+I*(a_0h_mu[kk]),b_mu_0 + (a_0h_mu[kk])*S)

        TT                     = S/b_0h_mu[kk+1] - R + I*log(b_0h_mu[kk+1]) - I

        A                      = a_0h + I/2
        B                      = b_0h + TT

        for(mm in 1:M){

          a    = A/B
          A    = a_0h - I*a + I * a^2*trigamma(a)
          B    = b_0h + (A-a_0h)/a - I*log(a) + I*digamma(a)+TT

          if(abs(a/(A/B)-1)<toll){break}
        }

        a_0h_mu[kk+1]  = rgamma(1,A,B)



        # alpha_h

        R                      = sum(log(alpha_h_i[,kk+1]))
        S                      = sum(alpha_h_i[,kk+1])

        b_0h_alpha[kk+1]       = rinvgamma(1,a_mu_0+I*(a_0h_alpha[kk]),b_mu_0 + (a_0h_alpha[kk])*S)

        TT                     = S / b_0h_alpha[kk+1] - R + I*log(b_0h_alpha[kk+1]) - I

        A                      = a_0h + I/2
        B                      = b_0h + TT

        for(mm in 1:M){

          a    = A/B
          A    = a_0h - I*a + I * a^2*trigamma(a)
          B    = b_0h + (A-a_0h)/a - I*log(a) +I*digamma(a)+TT

          if(abs(a/(A/B)-1)<toll){break}
        }

        a_0h_alpha[kk+1]  = rgamma(1,A,B)



      }






      #----- Parametric Mixture monitoring for subjects mixture

      s_grid                  = array( 0, dim = c( J, length(Grid_s)) )
      p_grid                  = array(0, dim = c(nMaxClusters_s, length(Grid_s)))

      for(h in 1:nMaxClusters_s){
        p_grid[h,] = pi_c_s[kk+1,h] %*% dnorm(Grid_s, phi_s[h,,kk+1]+mean_mix_r[kk+1], sqrt(sigma_s[kk+1,,h]))
      }

      par_monitoring_s[,kk+1]   = apply(p_grid,2,sum)


      #----- Parametric Mixture monitoring for raters mixture

      s_grid                  = array( 0, dim = c( I, length(Grid)) )
      p_grid                  = array(0, dim = c(nMaxClusters, length(Grid)))

      for(h in 1:nMaxClusters){
        p_grid[h,] = pi_c_r[kk+1,h] %*% dnorm(Grid, phi[h,1,kk+1]-mean_mix_r[kk+1], sqrt(sigma_b[kk+1,1,h]))
      }

      par_monitoring[,kk+1]   = apply(p_grid,2,sum)



      #----- Parametric Mixture monitoring for raters reliability

      s_grid                  = array( 0, dim = c( I, length(Grid_rel)) )
      p_grid                  = array(0, dim = c(nMaxClusters, length(Grid_rel)))

      for(h in 1:nMaxClusters){
        p_grid[h,] = pi_c_r[kk+1,h] %*% dgamma(Grid_rel, alpha_h[h,kk+1]+1,(alpha_h[h,kk+1]+1)/mu_h[h,kk+1])
      }

      par_monitoring_rel[,kk+1]   = apply(p_grid,2,sum) #######




      if (kk %% 50 == 0) {
        par(mfrow=c(2,2))
        print(paste(paste(paste("iteration: ",kk,sep="")," of ", nIter, sep="")," complete."))

      }

    }

    end.time <- Sys.time()
    time.taken <- round(end.time - start.time,2)
    print(paste("Elapsed time :",time.taken))

  }


  # Output

  return(
    list(
      mu_0               = mu_0              ,
      sigma_0            = sigma_0           ,
      eta_0              = eta_0             ,
      sigma_eta_0        = sigma_eta_0       ,
      phi                = phi               ,
      sigma_b            = sigma_b           ,
      phi_s              = phi_s             ,
      sigma_s            = sigma_s           ,
      mean_mix_s         = mean_mix_s        ,
      var_mix_s          = var_mix_s         ,
      mean_mix_r         = mean_mix_r        ,
      var_mix_r          = var_mix_r         ,
      var_rel            = var_rel           ,
      ICC_a              = ICC_a             ,
      pi_c_r             = pi_c_r            ,
      pi_c_s             = pi_c_s            ,
      c_s                = c_s               ,
      c_r                = c_r               ,
      N_groups_s         = N_groups_s        ,
      N_groups           = N_groups          ,
      ni_c_s             = ni_c_s            ,
      ni_c               = ni_c              ,
      alpha_0_1          = alpha_0_1         ,
      alpha_0            = alpha_0           ,
      nu_1               = nu_1              ,
      nu                 = nu                ,
      theta              = theta             ,
      theta_C            = theta_C           ,
      b                  = b                 ,
      pi_c_s             = pi_c_s            ,
      pi_c_r             = pi_c_r            ,
      b_C                = b_C               ,
      mu                 = mu                ,
      sigma              = sigma             ,
      eta                = eta               ,
      omega              = omega             ,
      sigma_2            = sigma_2           ,
      precis_2           = precis_2          ,
      par_monitoring_s   = par_monitoring_s  ,
      par_monitoring     = par_monitoring    ,
      par_monitoring_rel = par_monitoring_rel,
      MSE_precis_2       = MSE_precis_2      ,
      mu_h               = mu_h              ,
      alpha_h            = alpha_h           ,
      mu_h_i             = mu_h_i            ,
      alpha_h_i          = alpha_h_i         ,
      sigma_mean         = sigma_mean        ,
      a_sigma            = a_sigma           ,
      sigma_mean_b       = sigma_mean_b      ,
      a_sigma_b          = a_sigma_b         ,
      a_0h_mu            = a_0h_mu           ,
      b_0h_mu            = b_0h_mu           ,
      a_0h_alpha         = a_0h_alpha        ,
      b_0h_alpha         = b_0h_alpha        )
  )

}

