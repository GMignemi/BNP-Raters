#Hyper-priors

m_0             = array( 50, dim = 1 ) # mean of Base measure for the subjects
m_0_r           = array( 0, dim = 1 )  # mean of Base measure for the raters systematic bias  
sigma_s_0       = array( 100, dim = 1 )# variance of Base measure for the raters systematic bias
a_0             = 0.005
b_0             = 0.005
a_b             = 0.005
b_b             = 0.005
a_alpha         = 1                    
b_alpha         = 1
a_alpha_1       = 1
b_alpha_1       = 1
a_0h            = 0.005
b_0h            = 0.005
a_mu_0          = 0.005
b_mu_0          = 0.005

Priors = list(
  m_0,   
  m_0_r,    
  sigma_s_0,
  a_0,      
  b_0,      
  a_b,      
  b_b,      
  a_alpha,  
  b_alpha,  
  a_alpha_1,
  b_alpha_1,
  a_0h,     
  b_0h,     
  a_mu_0,   
  b_mu_0   
)
names(Priors) = c(
  "m_0",   
  "m_0_r",    
  "sigma_s_0",
  "a_0",      
  "b_0",      
  "a_b",      
  "b_b",      
  "a_alpha",  
  "b_alpha",  
  "a_alpha_1",
  "b_alpha_1",
  "a_0h",     
  "b_0h",     
  "a_mu_0",   
  "b_mu_0"   
)
