R_BNP_WAIC = function(
    data,
    R_BNP_mcmc_output,
    NE
){
  
  if (!require(mvtnorm)) install.packages("Rmpfr")
  library("Rmpfr")
  
  
  attach(R_BNP_mcmc_output)
  pi_c_s_1 = pi_c_s
  pi_c_r_1 = pi_c_r
  
  phi_s_1  = phi_s
  sigma_s_1= sigma_s
  
  phi_1    = phi
  sigma_b_1= sigma_b
  
  alpha_h_1= alpha_h
  mu_h_1   = mu_h
  
  tot = length(as.numeric(data[,1]))
  
  y_star        = array(0, dim = c(tot, NE+1))

  for(kk in 1:NE){
    for(nn in 1:tot){
      
      a_j = rnorm(1,mu_0_1[kk+1] ,sqrt(sigma_0[kk+1]))
      b_j = rnorm(1,eta_0_1[kk+1],sqrt(sigma_eta_0_1[kk+1]))
      c_j = rgamma(1,alpha_h_1[kk+1]+1,(alpha_h_1[kk+1]+1)/mu_h_1[kk+1])
      
      theta_star[nn,kk+1] = a_j
      y_star[nn,kk+1]     = rnorm(1, a_j + b_j ,1/sqrt( c_j ) )
      
    } 

  }
  
  return(y_star)
  
}